# README #

Bridges Vilota eCal messages to ROS2

### How do I get set up? ###
* Summary of set up
* Configuration
* Dependencies

```bash
pip install transforms3d==0.4.2 # fix for module 'numpy' has no attribute 'float', requires transforms3d >= 0.4.1
pip install pycapnp==1.3.0 # importing doesn't seem to work well for 2.0.0
sudo apt install capnproto ros-humble-tf-transformations
```

Instructions specific to Nvidia Orin Ubuntu 22.04
```bash
sudo apt install libopencv-dev=4.5.4+dfsg-9ubuntu4
pip3 install "numpy<2.0"
```

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* william.leong@nus.edu.sg