import launch
import launch_ros.actions

def generate_launch_description():
    return launch.LaunchDescription([
        # Front left
        launch_ros.actions.Node(
            package='vilota_bridge',
            executable='vilota_bridge_node',
            output='screen',
            
            name='vilota_bridge_front_left',
            parameters=[
                {'bridge_name': 'front_left'},
                {'disparity_topic': 'S1/stereo1_l/disparity'},
                {'image_topic': 'S1/stereo1_l'},
                {'odom_topic': 'S1/vio_odom_ned'}
            ]),

        # Front right
        launch_ros.actions.Node(
            package='vilota_bridge',
            executable='vilota_bridge_node',
            output='screen',

            name='vilota_bridge_front_right',
            parameters=[
                {'bridge_name': 'front_right'},
                {'disparity_topic': 'S1/stereo2_r/disparity'},
                {'image_topic': 'S1/stereo2_r'},
                {'odom_topic': 'S1/vio_odom_ned'}
            ]),

        # # Back left
        # launch_ros.actions.Node(
        #     package='vilota_bridge',
        #     executable='vilota_bridge_node',
        #     output='screen',

        #     name='vilota_bridge_back_left',
        #     parameters=[
        #         {'bridge_name': 'back_left'},
        #         {'disparity_topic': 'S0/stereo1_l/disparity'},
        #         {'image_topic': 'S0/stereo1_l'},
        #         {'odom_topic': 'S0/vio_odom'}
        #     ]),

        # # Back right
        # launch_ros.actions.Node(
        #     package='vilota_bridge',
        #     executable='vilota_bridge_node',
        #     output='screen',

        #     name='vilota_bridge_back_right',
        #     parameters=[
        #         {'bridge_name': 'back_right'},
        #         {'disparity_topic': 'S0/stereo2_r/disparity'},
        #         {'image_topic': 'S0/stereo2_r'},
        #         {'odom_topic': 'S0/vio_odom'}
        #     ]),
  ])
