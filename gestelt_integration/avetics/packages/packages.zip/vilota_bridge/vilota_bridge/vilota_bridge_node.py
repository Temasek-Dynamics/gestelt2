import multiprocessing, ctypes

# External libraries
import ecal.core.core as ecal_core

from vilota_bridge.vilota_bridge import VilotaBridge

import rclpy
from rclpy.executors import MultiThreadedExecutor

from vilota_bridge.capnp_subscriber import CapnpSubscriber

def main():
    rclpy.init()

    mtExecutor = MultiThreadedExecutor()

    vilota_bridge = VilotaBridge()
    mtExecutor.add_node(vilota_bridge)

    try:
        mtExecutor.spin()
    except KeyboardInterrupt:
        pass
    except ExternalShutdownException:
        sys.exit(1)
    finally:
        vilota_bridge.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
