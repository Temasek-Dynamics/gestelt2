# ROS2
import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.qos import qos_profile_sensor_data

from geometry_msgs.msg import PoseStamped
from geometry_msgs.msg import TransformStamped
from sensor_msgs.msg import Image
from sensor_msgs.msg import CameraInfo

from tf2_ros.static_transform_broadcaster import StaticTransformBroadcaster
from tf2_ros import TransformBroadcaster
from tf2_ros.transform_listener import TransformListener
from tf2_ros.buffer import Buffer
from tf_transformations import *

from cv_bridge import CvBridge

import ecal.core.core as ecal_core

# capnp
from ament_index_python.packages import get_package_share_directory
capnp_path = get_package_share_directory('vilota_bridge') + '/capnp/'

import capnp
capnp.add_import_hook([capnp_path])

from vilota_bridge.capnp_subscriber import CapnpSubscriber
import disparity_capnp as eCALDiaprity # type: ignore
import image_capnp as eCALImage # type: ignore
import odometry3d_capnp as eCALOdometry3d # type: ignore

import cv2
import numpy as np

import multiprocessing

from scipy.spatial.transform import Rotation as R

# Abstract away all the ROS stuff
class VilotaBridge(Node):
    def publishDepth(self, currentDepth, timestamp):

        imageMsg = self.cvBridge.cv2_to_imgmsg(currentDepth)
        imageMsg.encoding = "32FC1"
        imageMsg.header.frame_id = self.cameraFrameID
        imageMsg.header.stamp = timestamp
        self.depthPublisher.publish(imageMsg)

    def getDepthImage(self, disparityMsg):
        MAX_DEPTH = 20

        mat_uint16 = np.frombuffer(disparityMsg.data, dtype=np.uint16)
        mat_uint16 = mat_uint16.reshape((disparityMsg.height, disparityMsg.width, 1))

        mat_float32 = mat_uint16.astype(np.float32) / 8.0

        mat_float32 = cv2.medianBlur(mat_float32, 5) # 5x5 median filter
        # mat_float32 = cv2.bilateralFilter(mat_float32, 9, 75, 75) # 9x9 bilateral filter

        # Calculate depth, limiting the minimum disparity+
        # epsilon = 1e-1 # Huimin says this will let the error be more conservative compared to 1e-5
        epsilon = 1e-5

        # # Scale focal length (disparity image is halved of the orignal focal length)
        # fx = disparityMsg.fx / 2.0
        fx = disparityMsg.fx
        
        # units = 0.001
        # depth = (disparityMsg.baseline * fx / (units * mat_float32 + epsilon)) / 1000.0

        # Equivalent to above cos 0.001 and 1000 cancels each other out? Why didn't it work earlier on then?
        depth = (disparityMsg.baseline * fx / (mat_float32 + epsilon))

        depth = np.minimum(depth, MAX_DEPTH)

        return depth

    def getCameraInfo(self, disparityMsg):
        cameraInfoMsg = CameraInfo()
        cameraInfoMsg.width = disparityMsg.width
        cameraInfoMsg.height = disparityMsg.height
        cameraInfoMsg.header.frame_id = self.cameraFrameID

        # Intrinsic camera matrix for the raw (distorted) images.
        #     [fx  0 cx]
        # K = [ 0 fy cy]
        #     [ 0  0  1]
        # Projects 2D points in the camera coordinate frame to 3D pixel
        # coordinates using the focal lengths (fx, fy) and principal point
        # (cx, cy).

        # camera info from disparity is based on 640x400 image, not disparity, so we need to divide
        fx = disparityMsg.fx / 2.0
        fy = disparityMsg.fy / 2.0
        cx = disparityMsg.cx / 2.0
        cy = disparityMsg.cy / 2.0

        cameraInfoMsg.k = [fx, 0.0, cx, 0.0, fy, cy, 0.0, 0.0, 1.0]

        return cameraInfoMsg

    def publishCameraInfo(self, cameraInfoMsg, timestamp):
        cameraInfoMsg.header.stamp = timestamp 
        self.cameraInfoPublisher.publish(cameraInfoMsg)

    # def processOdometry(self, running, bridge_name, odometryTopic, dynamicTransformsQueue):
    #     # ROS stuff
    #     odomToBaseLinkTF = TransformStamped()
    #     odomToBaseLinkTF.header.frame_id = "odom"
    #     odomToBaseLinkTF.child_frame_id = "base_link"

    #     # Init ecal and subscriptions
    #     ecal_core.initialize([], f"[{bridge_name}] {odometryTopic}")
    #     self.get_logger().info(f"[{bridge_name}] Subscribing from eCal {odometryTopic}")

    #     odometrySub = CapnpSubscriber("Odometry3d", odometryTopic)

    #     while running.value and ecal_core.ok():
    #         # wait for message to come in
    #         ret, msg, _ = odometrySub.receive(1) # timeout/sleep for 1 ms

    #         if not ret:
    #             continue

    #         # Odom pose is NWU, master unit faces backwards
    #         with eCALOdometry3d.Odometry3d.from_bytes(msg) as odometryMsg:
    #             # translation/position
    #             odomToBaseLinkTF.transform.translation.x = odometryMsg.pose.position.x
    #             odomToBaseLinkTF.transform.translation.y = odometryMsg.pose.position.y
    #             odomToBaseLinkTF.transform.translation.z = odometryMsg.pose.position.z

    #             # rotation/orientation
    #             odomToBaseLinkTF.transform.rotation.x = odometryMsg.pose.orientation.x
    #             odomToBaseLinkTF.transform.rotation.y = odometryMsg.pose.orientation.y
    #             odomToBaseLinkTF.transform.rotation.z = odometryMsg.pose.orientation.z
    #             odomToBaseLinkTF.transform.rotation.w = odometryMsg.pose.orientation.w

    #             # Send the transformation
    #             odomToBaseLinkTF.header.stamp = self.get_clock().now().to_msg()
    #             dynamicTransformsQueue.put(odomToBaseLinkTF)

    #     ecal_core.finalize()

    def publishImage(self, currentImage):
        currentImage = cv2.cvtColor(currentImage, cv2.COLOR_BGR2GRAY)

        currentTimestamp = self.get_clock().now().to_msg()
        imageMsg = self.cvBridge.cv2_to_imgmsg(currentImage)
        imageMsg.encoding = "mono8"
        imageMsg.header.frame_id = self.cameraFrameID
        imageMsg.header.stamp = currentTimestamp
        self.imagePublisher.publish(imageMsg)

    # def processImage(self, running, bridge_name, image_topic, staticTransformsQueue):
    #     ecal_core.initialize([], f"[{bridge_name}] {image_topic}")
    #     self.get_logger().info(f"[{bridge_name}] Subscribing from eCal {image_topic}")
    #     imageSub = CapnpSubscriber("Image", image_topic)

    #     while running.value and ecal_core.ok():
    #         # wait for message to come in
    #         ret, msg, _ = imageSub.receive(1) # timeout/sleep for 1 ms

    #         if not ret:
    #             continue

    #         with eCALImage.Image.from_bytes(msg) as imageMsg:
    #             assert(imageMsg.encoding == "jpeg")

    #             currentImageJpeg = np.frombuffer(imageMsg.data, dtype=np.uint8)
    #             currentImage = cv2.imdecode(currentImageJpeg, cv2.IMREAD_COLOR)

    #             self.publishImage(currentImage)
    #             self.publishBaseLinkToCamera(bridge_name, staticTransformsQueue, imageMsg.extrinsic.bodyFrame)

    #     ecal_core.finalize()

    # Publishes 2 static TFs:
    #   1. Camera link -> Front Left Camera
    #   2. Base Link -> Camera Link
    def publishBaseLinkToCamera(self, bridge_name, staticTransformsQueue, transform):

        #############################
        # Camera Link -> Camera front left TF
        #############################
        # Should be FRD
        CameraLinkToCamera = TransformStamped()

        CameraLinkToCamera.header.stamp = self.get_clock().now().to_msg()
        CameraLinkToCamera.header.frame_id = "camera_link" # body of camera
        CameraLinkToCamera.child_frame_id = self.cameraFrameID # e.g. front left/front right

        position = [
            -transform.position.x * 0.001, 
            -transform.position.y * 0.001, 
            transform.position.z * 0.001
        ]
        orientation = [
            transform.orientation.x,
            transform.orientation.y,
            transform.orientation.z,
            transform.orientation.w
        ]

        CameraLinkToCamera.transform.translation.x = position[0] 
        CameraLinkToCamera.transform.translation.y = position[1]
        CameraLinkToCamera.transform.translation.z = position[2]

        r_cam_rotz_180 = R.from_euler('z', 180, degrees=True).as_matrix()
        r_quat = R.from_quat(orientation)
        orientation = R.from_matrix(r_cam_rotz_180) * r_quat 
        orientation = orientation.as_quat() #Quaternion in x,y,z,w order

        CameraLinkToCamera.transform.rotation.x = orientation[0]
        CameraLinkToCamera.transform.rotation.y = orientation[1]
        CameraLinkToCamera.transform.rotation.z = orientation[2]
        CameraLinkToCamera.transform.rotation.w = orientation[3]

        staticTransformsQueue.put(CameraLinkToCamera)

        #############################
        # Base Link -> Camera Link TF
        #############################
        baseLinkToCameraTF = TransformStamped()

        baseLinkToCameraTF.header.stamp = self.get_clock().now().to_msg()
        baseLinkToCameraTF.header.frame_id = "base_link" 
        baseLinkToCameraTF.child_frame_id = "camera_link"

        baseLinkToCameraTF.transform.translation.x = 0.085
        baseLinkToCameraTF.transform.translation.y = 0.0
        baseLinkToCameraTF.transform.translation.z = 0.0

        # Rotation from base link to camera 
        r_cam_roty_n10 = R.from_euler('y', -10, degrees=True).as_matrix()
        r_quat = R.from_quat([0, 0, 0, 1])
        orientation = R.from_matrix(r_cam_roty_n10) * r_quat 
        orientation = orientation.as_quat() #Quaternion in x,y,z,w order

        baseLinkToCameraTF.transform.rotation.x = orientation[0]
        baseLinkToCameraTF.transform.rotation.y = orientation[1]
        baseLinkToCameraTF.transform.rotation.z = orientation[2]
        baseLinkToCameraTF.transform.rotation.w = orientation[3]

        staticTransformsQueue.put(baseLinkToCameraTF)


    def publishStaticTransforms(self):
        # currentTimestamp = self.get_clock().now().to_msg()
        # self.noChangeTF.header.stamp = currentTimestamp

        # https://docs.nav2.org/setup_guides/transformation/setup_transforms.html
        # world -> map -> odom -> base_link -> depth_xxx
        # self.noChangeTF.header.frame_id = "world"
        # self.noChangeTF.child_frame_id = self.mapFrameID
        # self.staticTransformBroadcaster.sendTransform(self.noChangeTF)

        # self.noChangeTF.header.frame_id = self.mapFrameID
        # self.noChangeTF.child_frame_id = "odom"
        # self.staticTransformBroadcaster.sendTransform(self.noChangeTF)

        while not self.staticTransformsQueue.empty():
            currentStaticTransform = self.staticTransformsQueue.get()
            self.staticTransformBroadcaster.sendTransform(currentStaticTransform)

    def publishDynamicTransforms(self):
        pass 

        while not self.dynamicTransformsQueue.empty():
            currentDynamicTransform = self.dynamicTransformsQueue.get()
            self.transformBroadcaster.sendTransform(currentDynamicTransform)

    # Tells the pose of camera relative to a fixed frame (odom)
    def publishCameraPose(self, bridge_name):
        transformFromFrame = "depth_" + bridge_name
        transformToFrame = "odom"

        if not self.transformBuffer.can_transform(transformToFrame, transformFromFrame, rclpy.time.Time()):
            return

        t = self.transformBuffer.lookup_transform(transformToFrame, transformFromFrame, rclpy.time.Time())

        # Update camera pose
        cameraPoseMsg = PoseStamped()
        cameraPoseMsg.header.frame_id = "odom"
        cameraPoseMsg.header.stamp = self.get_clock().now().to_msg()

        cameraPoseMsg.pose.position.x = t.transform.translation.x
        cameraPoseMsg.pose.position.y = t.transform.translation.y
        cameraPoseMsg.pose.position.z = t.transform.translation.z

        cameraPoseMsg.pose.orientation.x = t.transform.rotation.x
        cameraPoseMsg.pose.orientation.y = t.transform.rotation.y
        cameraPoseMsg.pose.orientation.z = t.transform.rotation.z
        cameraPoseMsg.pose.orientation.w = t.transform.rotation.w

        self.posePublisher.publish(cameraPoseMsg)

    def initPublishers(self, bridge_name):
        self.get_logger().info(f"[Bridge] {bridge_name}")

        depthPublisherTopic = f"/{bridge_name}/depth/rect"
        self.get_logger().info(f"[eCal] {self.disparity_topic} -> [ROS] {depthPublisherTopic}")
        self.depthPublisher = self.create_publisher(Image, depthPublisherTopic, qos_profile_sensor_data)
        self.create_publisher

        cameraInfoPublisherTopic = f"/{bridge_name}/depth/camera_info"
        self.get_logger().info(f"[eCal] {self.disparity_topic} -> [ROS] {cameraInfoPublisherTopic}")
        self.cameraInfoPublisher = self.create_publisher(CameraInfo, cameraInfoPublisherTopic, qos_profile_sensor_data)

        posePublisherTopic = f"/{bridge_name}/depth/pose"
        self.get_logger().info(f"[eCal] {self.odom_topic} -> [ROS] {posePublisherTopic}")
        self.posePublisher = self.create_publisher(PoseStamped, posePublisherTopic, qos_profile_sensor_data)

        imagePublisherTopic = f"/{bridge_name}/image/rect"
        self.get_logger().info(f"[eCal] {self.image_topic} -> [ROS] {imagePublisherTopic}")
        self.imagePublisher = self.create_publisher(Image, imagePublisherTopic, qos_profile_sensor_data)
    
    def disparitySubCallback(self, topic_name, msg, time):
        with eCALDiaprity.Disparity.from_bytes(msg) as disparityMsg:
            # disparity16 @1; # encoded as scaled disparity of scaling of 8
            assert(disparityMsg.encoding == "disparity16")

            currentTimestamp = self.get_clock().now().to_msg()

            depthImage = self.getDepthImage(disparityMsg)
            self.publishDepth(depthImage, currentTimestamp)

            cameraInfoMsg = self.getCameraInfo(disparityMsg)
            self.publishCameraInfo(cameraInfoMsg, currentTimestamp)

    def imageSubCallback(self, topic_name, msg, time):

        with eCALImage.Image.from_bytes(msg) as imageMsg:
            assert(imageMsg.encoding == "jpeg")

            currentImageJpeg = np.frombuffer(imageMsg.data, dtype=np.uint8)
            currentImage = cv2.imdecode(currentImageJpeg, cv2.IMREAD_COLOR)

            self.publishImage(currentImage)
            self.publishBaseLinkToCamera(
                self.bridge_name, self.staticTransformsQueue, imageMsg.extrinsic.bodyFrame)

    def odomSubCallback(self, topic_name, msg, time):

        # Odom pose is NWU, master unit faces backwards
        with eCALOdometry3d.Odometry3d.from_bytes(msg) as odometryMsg:
            
            position = np.array([
                odometryMsg.pose.position.x, 
                odometryMsg.pose.position.y, 
                odometryMsg.pose.position.z])
            orientation = np.array([
                odometryMsg.pose.orientation.x, 
                odometryMsg.pose.orientation.y, 
                odometryMsg.pose.orientation.z, 
                odometryMsg.pose.orientation.w])

            # #####
            # # TF: For NWU VIO topic 'S1/vio_odoms'
            # #####

            # # Flip x and y axes
            # position_b = [
            #     -position[0], 
            #     -position[1], 
            #     position[2]]
            # # Convert from right handed coordinates to left handed coordinates 
            # orientation_b = [
            #     orientation[0], 
            #     orientation[1], 
            #     -orientation[2], 
            #     -orientation[3]]

            # worldToBaseLinkTF_b = TransformStamped()
            # worldToBaseLinkTF_b.header.frame_id = self.mapFrameID
            # worldToBaseLinkTF_b.child_frame_id = "base_link"

            # worldToBaseLinkTF_b.transform.translation.x = position_b[0]
            # worldToBaseLinkTF_b.transform.translation.y = position_b[1]
            # worldToBaseLinkTF_b.transform.translation.z = position_b[2]

            # worldToBaseLinkTF_b.transform.rotation.x = orientation_b[0]
            # worldToBaseLinkTF_b.transform.rotation.y = orientation_b[1]
            # worldToBaseLinkTF_b.transform.rotation.z = orientation_b[2]
            # worldToBaseLinkTF_b.transform.rotation.w = orientation_b[3]

            # # Send the transformation
            # worldToBaseLinkTF_b.header.stamp = self.get_clock().now().to_msg()
            # self.dynamicTransformsQueue.put(worldToBaseLinkTF_b)

            #####
            # TF: For NED VIO Topic, 'S1/vio_odoms_ned'
            #####

            # # Flip x and y axes 
            # position_c = [-position[0]-0.085, position[1], -position[2]]
            # # Convert from right handed coordinates to left handed coordinates 
            # # i.e. flip y axis (+ve y becomes -ve y)
            # orientation_c = [orientation[0], -orientation[1], orientation[2], -orientation[3]]

            # # Rotation from base link to camera frame about y-axis 
            # r_cam_roty_n10 = R.from_euler('y', -10, degrees=True).as_matrix()
            # r_quat = R.from_quat(orientation_c)
            # orientation_c = R.from_matrix(r_cam_roty_n10).inv() * r_quat 
            # orientation_c = orientation_c.as_quat() #Quaternion in x,y,z,w order

            # worldToBaseLinkTF_c = TransformStamped()
            # worldToBaseLinkTF_c.header.frame_id = self.mapFrameID
            # worldToBaseLinkTF_c.child_frame_id = "base_link"

            # worldToBaseLinkTF_c.transform.translation.x = position_c[0]
            # worldToBaseLinkTF_c.transform.translation.y = position_c[1]
            # worldToBaseLinkTF_c.transform.translation.z = position_c[2]

            # worldToBaseLinkTF_c.transform.rotation.x = orientation_c[0]
            # worldToBaseLinkTF_c.transform.rotation.y = orientation_c[1]
            # worldToBaseLinkTF_c.transform.rotation.z = orientation_c[2]
            # worldToBaseLinkTF_c.transform.rotation.w = orientation_c[3]

            # # Send the transformation
            # worldToBaseLinkTF_c.header.stamp = self.get_clock().now().to_msg()
            # self.dynamicTransformsQueue.put(worldToBaseLinkTF_c)

            # # #############################
            # # # Base Link -> Camera Front Left TF
            # # #############################
            # baseLinkToCameraTF = TransformStamped()

            # baseLinkToCameraTF.header.stamp = self.get_clock().now().to_msg()
            # baseLinkToCameraTF.header.frame_id = "base_link" 
            # baseLinkToCameraTF.child_frame_id = self.cameraFrameID

            # baseLinkToCameraTF.transform.translation.x = 0.085
            # baseLinkToCameraTF.transform.translation.y = 0.0
            # baseLinkToCameraTF.transform.translation.z = 0.0

            # baseLinkToCameraTF.transform.rotation.x = -0.577
            # baseLinkToCameraTF.transform.rotation.y = 0.304
            # baseLinkToCameraTF.transform.rotation.z = -0.409
            # baseLinkToCameraTF.transform.rotation.w = 0.638

            # self.staticTransformsQueue.put(baseLinkToCameraTF)

    def __init__(self):
        super().__init__("vilota_bridge")
        
        # Params
        self.declare_parameter("bridge_name", rclpy.Parameter.Type.STRING)
        self.declare_parameter("disparity_topic", rclpy.Parameter.Type.STRING)
        self.declare_parameter("image_topic", rclpy.Parameter.Type.STRING)
        self.declare_parameter("odom_topic", rclpy.Parameter.Type.STRING)
        self.declare_parameter("map_frame_id", rclpy.Parameter.Type.STRING)
        self.declare_parameter("camera_frame_id", rclpy.Parameter.Type.STRING)

        self.bridge_name = self.get_parameter('bridge_name').value
        self.disparity_topic = self.get_parameter('disparity_topic').value
        self.image_topic = self.get_parameter('image_topic').value
        self.odom_topic = self.get_parameter('odom_topic').value
        self.mapFrameID = self.get_parameter('map_frame_id').value
        self.cameraFrameID = self.get_parameter('camera_frame_id').value

        # Create all ROS publisher/subscriber/callbacks in same context to prevent problems
        self.initPublishers(self.bridge_name)
        self.timerCallbackGroup = ReentrantCallbackGroup() # run all timers in parallel

        # OpenCV
        self.cvBridge = CvBridge()

        # Transforms queues
        # multiprocessing doesn't play well with ROS transform publishers
        # so we need them all on the same ROS context
        TRANSFORMS_PUBLISH_INTERVAL = 1.0 / 16.0 # seconds

        self.staticTransformsQueue = multiprocessing.Queue()
        self.dynamicTransformsQueue = multiprocessing.Queue()

        # Static transforms
        self.noChangeTF = TransformStamped()

        self.noChangeTF.transform.translation.x = 0.0
        self.noChangeTF.transform.translation.y = 0.0
        self.noChangeTF.transform.translation.z = 0.0

        self.noChangeTF.transform.rotation.x = 0.0
        self.noChangeTF.transform.rotation.y = 0.0
        self.noChangeTF.transform.rotation.z = 0.0
        self.noChangeTF.transform.rotation.w = 1.0
        self.staticTransformBroadcaster = StaticTransformBroadcaster(self)
        self.staticTransformsTimer = self.create_timer(TRANSFORMS_PUBLISH_INTERVAL, self.publishStaticTransforms, callback_group=self.timerCallbackGroup)

        # Dynamic transforms
        self.transformBroadcaster = TransformBroadcaster(self)
        self.transformBuffer = Buffer()
        self.transformListener = TransformListener(self.transformBuffer, self)

        self.dynamicTransformsTimer = self.create_timer(TRANSFORMS_PUBLISH_INTERVAL, self.publishDynamicTransforms, callback_group=self.timerCallbackGroup)
        self.cameraPoseTimer = self.create_timer(TRANSFORMS_PUBLISH_INTERVAL, lambda: self.publishCameraPose(self.bridge_name), callback_group=self.timerCallbackGroup)

        # Camera link

        # eCal
        ecal_core.initialize([], "vilota_bridge_" + self.bridge_name)
        
        disparitySub = CapnpSubscriber("Disparity", self.disparity_topic)
        disparitySub.set_callback(self.disparitySubCallback)

        # imageSub = CapnpSubscriber("Image", self.image_topic)
        # imageSub.set_callback(self.imageSubCallback)

        # odomSub = CapnpSubscriber("Odometry3d", self.odom_topic)
        # odomSub.set_callback(self.odomSubCallback)